#!/bin/bash

FULL_NAME=$(basename "$0")
if [ "$FULL_NAME" == "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

BASE_NAME="${FULL_NAME%.*}"
LOG_FILE="report_${BASE_NAME}.log"
FIFO_PATH="/tmp/my_fifo"

log_msg() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$1] $2" >> "$LOG_FILE"
}

MY_PID=$$
log_msg "$MY_PID" "Скрипт запущен"

CUCKOO_PID=$(pgrep -f "cuckoo.sh" | head -n 1)

if [ -z "$CUCKOO_PID" ]; then
    log_msg "$MY_PID" "Ошибка: cuckoo.sh не запущен"
    exit 1
fi

if [ ! -p "$FIFO_PATH" ]; then
    log_msg "$MY_PID" "Ошибка: канал $FIFO_PATH не найден"
    exit 1
fi

echo "$BASE_NAME[$MY_PID]: how much time do I have?" > "$FIFO_PATH"

read -r N < "$FIFO_PATH"

if [[ ! "$N" =~ ^[0-9]+$ ]]; then
    N=5 
fi

sleep "$N"

log_msg "$MY_PID" "Скрипт завершился, работал $N секунд"
