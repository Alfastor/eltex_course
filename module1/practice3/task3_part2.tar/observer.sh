#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

log_msg() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

if [ ! -f "$CONFIG_FILE" ]; then
    log_msg "Ошибка: файл конфигурации $CONFIG_FILE не найден"
    exit 1
fi

while IFS= read -r script_name; do
    if [ -z "$script_name" ]; then
        continue
    fi

    if ! pgrep -f "$script_name" > /dev/null; then
        nohup "./$script_name" > /dev/null 2>&1 &
        log_msg "Перезапуск: $script_name"
    fi
done < "$CONFIG_FILE"
