#!/bin/bash

FIFO_PATH=""
LOG_FILE="cuckoo.log"

for arg in "$@"; do
    case $arg in
        --pishitesuda=*)
        FIFO_PATH="${arg#*=}"
        shift
        ;;
    esac
done

if [ -z "$FIFO_PATH" ]; then
    exit 1
fi

log_msg() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

shutdown() {
    log_msg "Shutdown!"
    rm -f "$FIFO_PATH"
    exit 0
}
trap shutdown SIGTERM SIGINT

rm -f "$FIFO_PATH"
mkfifo "$FIFO_PATH"
chmod 666 "$FIFO_PATH"
log_msg "Startup!"

while true; do
    if read -r line < "$FIFO_PATH"; then
        if [[ "$line" =~ ^[0-9]+$ ]]; then
            continue
        fi
        name_pid="${line%%:*}"
        N=$(( (RANDOM % 9) + 2 ))
        echo "$N" > "$FIFO_PATH"
        log_msg "$name_pid $N"
    fi
done
